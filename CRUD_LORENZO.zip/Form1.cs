﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace CRUD_oop_IM
{
    public partial class Form1 : Form
    {
        // Update this with your MySQL credentials
        string connectionString = "server=localhost;user=root;password=lorenzo.maui11212005;database=task_tracker;";

        public Form1()
        {
            InitializeComponent();
            TestConnection();
        }

        private void TestConnection()
        {
            using (var mySqlConnection = new MySqlConnection(connectionString))
            {
                try
                {
                    mySqlConnection.Open();
                    MessageBox.Show("Connection successful!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Connection failed: " + ex.Message);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void addbtn_Click(object sender, EventArgs e)
        {

        }

        private void logInBtn_Click(object sender, EventArgs e)
        {
            string username = txtUsername?.Text?.Trim() ?? "";
            string password = txtPassword?.Text ?? "";

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter username and password.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var mySqlConnection = new MySqlConnection(connectionString))
                {
                    mySqlConnection.Open();

                    // Get stored password (hash) for the username
                    using (var cmd = new MySqlCommand("SELECT password FROM userdb WHERE username = @username LIMIT 1", mySqlConnection))
                    {
                        cmd.Parameters.AddWithValue("@username", username);
                        var result = cmd.ExecuteScalar();
                        if (result == null || result == DBNull.Value)
                        {
                            MessageBox.Show("Invalid username or password.");
                            return;
                        }

                        string storedHash = result.ToString();

                        // Verify supplied password against stored hash (format: iterations.salt.hash)
                        if (VerifyPassword(password, storedHash))
                        {
                            MessageBox.Show("Login successful!");
                            this.Hide();
                            Form3 taskForm = new Form3();
                            taskForm.Show();
                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Login error: " + ex.Message);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Form2 registerForm = new Form2();
            registerForm.Show();
            this.Hide();
        }

        // PBKDF2 verify helper (must match CreatePasswordHash used when creating users)
        private static bool VerifyPassword(string password, string storedHash)
        {
            try
            {
                var parts = storedHash.Split('.');
                if (parts.Length != 3) return false;
                int iterations = int.Parse(parts[0]);
                byte[] salt = Convert.FromBase64String(parts[1]);
                byte[] stored = Convert.FromBase64String(parts[2]);

                using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations))
                {
                    byte[] computed = pbkdf2.GetBytes(stored.Length);
                    return AreEqual(stored, computed);
                }
            }
            catch
            {
                return false;
            }
        }

        private static bool AreEqual(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++)
                diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}