﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace CRUD_oop_IM
{
    public partial class Form3 : Form
    {
        private readonly BindingList<TaskItem> tasks = new BindingList<TaskItem>();
        private readonly string dataFile;

        public Form3()
        {
            InitializeComponent();

            // Use a small local file for persistence (optional)
            dataFile = Path.Combine(Application.StartupPath, "tasks.xml");

            // Bind list to grid (keeps UI responsive)
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = tasks;

            // Make TaskID read-only (IDs are managed automatically)
            txtTaskID.ReadOnly = true;

            // Populate status options
            cmbStatus.Items.Clear();
            cmbStatus.Items.AddRange(new object[] { "Pending", "In Progress", "Done" });

            LoadTasks();
        }

        private void LoadTasks()
        {
            try
            {
                if (File.Exists(dataFile))
                {
                    using (var stream = File.OpenRead(dataFile))
                    {
                        var serializer = new XmlSerializer(typeof(List<TaskItem>));
                        var list = (List<TaskItem>)serializer.Deserialize(stream);
                        tasks.Clear();
                        foreach (var t in list.OrderByDescending(x => x.Id))
                            tasks.Add(t);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading tasks: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveTasks()
        {
            try
            {
                var list = new List<TaskItem>(tasks);
                using (var stream = File.Create(dataFile))
                {
                    var serializer = new XmlSerializer(typeof(List<TaskItem>));
                    serializer.Serialize(stream, list);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving tasks: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int NextId()
        {
            return tasks.Count == 0 ? 1 : tasks.Max(t => t.Id) + 1;
        }

        private void addbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Title is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var item = new TaskItem
            {
                Id = NextId(),
                Title = txtTitle.Text.Trim(),
                Description = txtDescription.Text.Trim(),
                DueDate = dateTimePicker1.Value.Date,
                Status = cmbStatus.Text ?? ""
            };

            tasks.Add(item);
            SaveTasks();
            ClearFields();
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtTaskID.Text, out int id))
            {
                MessageBox.Show("Select a task to update.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var item = tasks.FirstOrDefault(t => t.Id == id);
            if (item == null)
            {
                MessageBox.Show("Task not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Title is required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            item.Title = txtTitle.Text.Trim();
            item.Description = txtDescription.Text.Trim();
            item.DueDate = dateTimePicker1.Value.Date;
            item.Status = cmbStatus.Text ?? "";

            // Refresh grid and persist
            dataGridView1.Refresh();
            SaveTasks();
            ClearFields();
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtTaskID.Text, out int id))
            {
                MessageBox.Show("Select a task to delete.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var item = tasks.FirstOrDefault(t => t.Id == id);
            if (item == null)
            {
                MessageBox.Show("Task not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this task?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            tasks.Remove(item);
            SaveTasks();
            ClearFields();
        }

        private void clearbtn_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            txtTaskID.Clear();
            txtTitle.Clear();
            txtDescription.Clear();
            cmbStatus.SelectedIndex = -1;
            dateTimePicker1.Value = DateTime.Today;
            dataGridView1.ClearSelection();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.DataBoundItem == null)
            {
                ClearFields();
                return;
            }

            var selected = (TaskItem)dataGridView1.CurrentRow.DataBoundItem;
            txtTaskID.Text = selected.Id.ToString();
            txtTitle.Text = selected.Title;
            txtDescription.Text = selected.Description;
            dateTimePicker1.Value = selected.DueDate;
            cmbStatus.Text = selected.Status;
        }
    }

    // Simple DTO for in-memory tasks; Xml-serializable
    public class TaskItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public string Status { get; set; }
    }
}
