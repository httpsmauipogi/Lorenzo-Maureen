﻿using MySql.Data.MySqlClient;
using System;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace CRUD_oop_IM
{
    public partial class Form2 : Form
    {
        private readonly string connectionString = "server=localhost;user=root;password=lorenzo.maui11212005;database=task_tracker;";

        public Form2()
        {
            InitializeComponent();
            // Optional: remove the test in production
            TestConnection();
        }

        private void TestConnection()
        {
            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    MessageBox.Show("Connection successful!", "DB", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection failed: " + ex.Message, "DB Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void signupBtn_Click(object sender, EventArgs e)
        {
            string email = txtEmail?.Text?.Trim() ?? "";
            string username = txtUsername?.Text?.Trim() ?? "";
            string password = txtPassword?.Text ?? "";

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter Email, Username and Password.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Check duplicates (username or email)
                    using (var checkCmd = new MySqlCommand("SELECT COUNT(1) FROM userdb WHERE username = @username OR email = @email", conn))
                    {
                        checkCmd.Parameters.AddWithValue("@username", username);
                        checkCmd.Parameters.AddWithValue("@email", email);
                        var exists = Convert.ToInt32(checkCmd.ExecuteScalar());
                        if (exists > 0)
                        {
                            MessageBox.Show("Username or email already exists.", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // Hash password using PBKDF2 (store iterations.salt.hash)
                    string passwordHash = CreatePasswordHash(password);

                    // Insert user record into userdb table (password column)
                    using (var insertCmd = new MySqlCommand("INSERT INTO userdb (email, username, password) VALUES (@email, @username, @password)", conn))
                    {
                        insertCmd.Parameters.AddWithValue("@email", email);
                        insertCmd.Parameters.AddWithValue("@username", username);
                        insertCmd.Parameters.AddWithValue("@password", passwordHash);
                        insertCmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Account created!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Clear inputs and navigate to login
                txtEmail.Clear();
                txtUsername.Clear();
                txtPassword.Clear();

                this.Hide();
                var loginForm = new Form1();
                loginForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating account: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // PBKDF2 helpers
        private static string CreatePasswordHash(string password, int iterations = 10000, int saltSize = 16, int hashSize = 32)
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                byte[] salt = new byte[saltSize];
                rng.GetBytes(salt);

                using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations))
                {
                    byte[] hash = pbkdf2.GetBytes(hashSize);
                    // Format: iterations.saltBase64.hashBase64
                    return string.Format("{0}.{1}.{2}", iterations, Convert.ToBase64String(salt), Convert.ToBase64String(hash));
                }
            }
        }

        // Optional verify routine (also used in Form1's login)
        private static bool VerifyPassword(string password, string storedHash)
        {
            try
            {
                var parts = storedHash.Split('.');
                if (parts.Length != 3) return false;
                int iterations = int.Parse(parts[0]);
                byte[] salt = Convert.FromBase64String(parts[1]);
                byte[] stored = Convert.FromBase64String(parts[2]);

                using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations))
                {
                    byte[] computed = pbkdf2.GetBytes(stored.Length);
                    return AreEqual(stored, computed);
                }
            }
            catch
            {
                return false;
            }
        }

        private static bool AreEqual(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++)
                diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
